import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, ArrowRight, Sparkles } from 'lucide-react';

const Pikachu = ({ isTyping, mousePos }: { isTyping: boolean, mousePos: { x: number, y: number } }) => {
  const winWidth = typeof window !== 'undefined' ? window.innerWidth : 1000;
  const winHeight = typeof window !== 'undefined' ? window.innerHeight : 1000;
  
  const isMobile = winWidth < 768;
  const charX = isMobile ? winWidth / 2 : winWidth * 0.25 + 50; 
  const charY = isMobile ? 150 : winHeight / 2 + 100;

  const dx = mousePos.x - charX;
  const dy = mousePos.y - charY;
  const angle = Math.atan2(dy, dx);
  
  const maxDist = 4;
  const dist = Math.min(Math.sqrt(dx * dx + dy * dy) / 40, maxDist);
  
  const eyeX = Math.cos(angle) * dist;
  const eyeY = Math.sin(angle) * dist;

  return (
    <div className="relative">
      <AnimatePresence>
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, scale: 0, y: 10, rotate: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotate: 10 }}
            exit={{ opacity: 0, scale: 0 }}
            className="absolute -top-8 right-4 z-20 text-red-500"
          >
            <Sparkles size={32} fill="currentColor" />
          </motion.div>
        )}
      </AnimatePresence>
      <svg viewBox="0 0 200 200" className="w-56 h-56 drop-shadow-xl overflow-visible">
        {/* Tail */}
        <motion.g animate={isTyping ? { rotate: [0, 10, -5, 0] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.5 }} style={{ originX: '140px', originY: '150px' }}>
          <path d="M 140 150 L 180 120 L 160 90 L 190 60 L 170 40 L 140 80 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3" strokeLinejoin="round"/>
        </motion.g>
        
        {/* Left Leg */}
        <motion.g animate={isTyping ? { y: [-5, 0, -5] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }} style={{ originX: '70px', originY: '170px' }}>
          <path d="M 60 160 Q 50 180 70 180 Q 80 180 80 160 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3"/>
        </motion.g>

        {/* Right Leg */}
        <motion.g animate={isTyping ? { y: [0, -5, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }} style={{ originX: '130px', originY: '170px' }}>
          <path d="M 120 160 Q 120 180 130 180 Q 150 180 140 160 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3"/>
        </motion.g>

        {/* Body (moves up and down slightly) */}
        <motion.g animate={isTyping ? { y: [0, -8, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }}>
          {/* Left Ear */}
          <motion.g animate={isTyping ? { rotate: -15 } : { rotate: 0 }} style={{ originX: '65px', originY: '65px' }}>
            <path d="M 65 65 L 20 10 L 85 45 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3" strokeLinejoin="round"/>
            <path d="M 40 35 L 20 10 L 55 25 Z" fill="#27272a"/>
          </motion.g>

          {/* Right Ear */}
          <motion.g animate={isTyping ? { rotate: 15 } : { rotate: 0 }} style={{ originX: '135px', originY: '65px' }}>
            <path d="M 135 65 L 180 10 L 115 45 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3" strokeLinejoin="round"/>
            <path d="M 160 35 L 180 10 L 145 25 Z" fill="#27272a"/>
          </motion.g>

          {/* Body Base */}
          <path d="M 50 100 Q 40 160 100 160 Q 160 160 150 100 Z" fill="#FACC15" stroke="#ca8a04" strokeWidth="3"/>
          
          {/* Head */}
          <ellipse cx="100" cy="90" rx="55" ry="50" fill="#FACC15" stroke="#ca8a04" strokeWidth="3"/>
          
          {/* Cheeks */}
          <circle cx="55" cy="105" r="10" fill="#EF4444"/>
          <circle cx="145" cy="105" r="10" fill="#EF4444"/>
          
          {/* Eyes Group (Fixed sockets, moving pupils) */}
          <g>
            {/* Left Eye Socket */}
            <circle cx="75" cy="85" r="9" fill="#27272a"/>
            {/* Right Eye Socket */}
            <circle cx="125" cy="85" r="9" fill="#27272a"/>
          </g>
          
          <motion.g animate={{ x: eyeX, y: eyeY, scale: isTyping ? 1.2 : 1 }} style={{ originX: '100px', originY: '85px' }}>
            {/* Left Pupil */}
            <circle cx="73" cy="83" r="3" fill="#FFF"/>
            {/* Right Pupil */}
            <circle cx="123" cy="83" r="3" fill="#FFF"/>
          </motion.g>
          
          {/* Nose */}
          <circle cx="100" cy="98" r="2" fill="#27272a"/>
          
          {/* Mouth */}
          <motion.path
            d={isTyping ? "M 90 105 Q 100 135 110 105 Z" : "M 90 105 Q 100 112 110 105"}
            fill={isTyping ? "#EF4444" : "none"}
            stroke="#27272a"
            strokeWidth="2"
            strokeLinecap="round"
          />
          
          {/* Arms */}
          <motion.g animate={isTyping ? { rotate: [-30, 40, -30] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.2 }} style={{ originX: '60px', originY: '130px' }}>
            <path d="M 60 130 Q 30 150 45 165" fill="none" stroke="#ca8a04" strokeWidth="8" strokeLinecap="round"/>
          </motion.g>
          <motion.g animate={isTyping ? { rotate: [30, -40, 30] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.2 }} style={{ originX: '140px', originY: '130px' }}>
            <path d="M 140 130 Q 170 150 155 165" fill="none" stroke="#ca8a04" strokeWidth="8" strokeLinecap="round"/>
          </motion.g>
        </motion.g>
      </svg>
    </div>
  );
};

const Jigglypuff = ({ isTyping, mousePos }: { isTyping: boolean, mousePos: { x: number, y: number } }) => {
  const winWidth = typeof window !== 'undefined' ? window.innerWidth : 1000;
  const winHeight = typeof window !== 'undefined' ? window.innerHeight : 1000;
  
  const isMobile = winWidth < 768;
  const charX = isMobile ? winWidth / 2 - 50 : winWidth * 0.25 - 50; 
  const charY = isMobile ? 150 : winHeight / 2 + 50;

  const dx = mousePos.x - charX;
  const dy = mousePos.y - charY;
  const angle = Math.atan2(dy, dx);
  
  const maxDist = 6;
  const dist = Math.min(Math.sqrt(dx * dx + dy * dy) / 30, maxDist);
  
  const eyeX = Math.cos(angle) * dist;
  const eyeY = Math.sin(angle) * dist;

  return (
    <div className="relative">
      <AnimatePresence>
        {isTyping ? (
          <motion.div
            key="typing-alert"
            initial={{ opacity: 0, scale: 0, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0 }}
            className="absolute -top-4 left-0 z-20 bg-white text-pink-500 font-black text-xl rounded-full w-10 h-10 flex items-center justify-center shadow-lg border-2 border-pink-400"
          >
            !
          </motion.div>
        ) : (
          <motion.div
            key="singing-note"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0, 0, 1, 1, 0, 0], 
              y: [0, 0, -10, -30, -40, -40],
              x: [0, 0, 8, -8, 0, 0],
              scale: [0.5, 0.5, 1, 1.2, 1, 1]
            }}
            transition={{ duration: 5, repeat: Infinity, times: [0, 0.6, 0.65, 0.85, 0.9, 1] }}
            className="absolute -top-4 right-4 z-20 text-pink-500 font-bold text-3xl drop-shadow-md"
          >
            ♪
          </motion.div>
        )}
      </AnimatePresence>
      <svg viewBox="0 0 200 200" className="w-48 h-48 drop-shadow-xl overflow-visible">
        
        {/* Left Foot */}
        <motion.g animate={isTyping ? { y: [-5, 0, -5] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }} style={{ originX: '60px', originY: '170px' }}>
          <path d="M 60 160 Q 40 190 75 178 Z" fill="#db2777"/>
        </motion.g>
        
        {/* Right Foot */}
        <motion.g animate={isTyping ? { y: [0, -5, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }} style={{ originX: '140px', originY: '170px' }}>
          <path d="M 140 160 Q 160 190 125 178 Z" fill="#db2777"/>
        </motion.g>

        {/* Body (moves up and down) */}
        <motion.g animate={isTyping ? { y: [0, -8, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.3 }}>
          {/* Left Ear */}
          <motion.g animate={isTyping ? { rotate: -10 } : { rotate: 0 }} style={{ originX: '60px', originY: '60px' }}>
            <path d="M 60 60 L 35 15 L 90 40 Z" fill="#F9A8D4" stroke="#db2777" strokeWidth="3" strokeLinejoin="round"/>
            <path d="M 55 45 L 42 22 L 75 35 Z" fill="#4B5563"/>
          </motion.g>
          
          {/* Right Ear */}
          <motion.g animate={isTyping ? { rotate: 10 } : { rotate: 0 }} style={{ originX: '140px', originY: '60px' }}>
            <path d="M 140 60 L 165 15 L 110 40 Z" fill="#F9A8D4" stroke="#db2777" strokeWidth="3" strokeLinejoin="round"/>
            <path d="M 145 45 L 158 22 L 125 35 Z" fill="#4B5563"/>
          </motion.g>

          {/* Body */}
          <circle cx="100" cy="110" r="70" fill="#F9A8D4" stroke="#db2777" strokeWidth="3"/>
          
          {/* Hair Tuft */}
          <path d="M 80 50 Q 110 10 130 50 Q 110 70 80 50 Z" fill="#F9A8D4" stroke="#db2777" strokeWidth="3" strokeLinejoin="round"/>
          <path d="M 95 35 Q 110 20 120 40" fill="none" stroke="#db2777" strokeWidth="2" strokeLinecap="round"/>
          
          {/* Eyes Group */}
          <g>
            {/* Left Sclera */}
            <circle cx="65" cy="100" r="20" fill="#FFF" stroke="#db2777" strokeWidth="2"/>
            {/* Right Sclera */}
            <circle cx="135" cy="100" r="20" fill="#FFF" stroke="#db2777" strokeWidth="2"/>
          </g>
          
          {/* Pupils Group */}
          <motion.g animate={{ x: eyeX, y: eyeY, scale: isTyping ? 1.1 : 1 }} style={{ originX: '100px', originY: '100px' }}>
            {/* Left Pupil */}
            <circle cx="68" cy="100" r="12" fill="#0EA5E9"/>
            <circle cx="64" cy="96" r="4" fill="#FFF"/>
            {/* Right Pupil */}
            <circle cx="132" cy="100" r="12" fill="#0EA5E9"/>
            <circle cx="128" cy="96" r="4" fill="#FFF"/>
          </motion.g>
          
          {/* Mouth */}
          <motion.path
            animate={
              isTyping
                ? { d: "M 90 125 Q 100 155 110 125 Z", fill: "#EF4444" }
                : { 
                    d: [
                      "M 95 125 Q 100 130 105 125", 
                      "M 95 125 Q 100 130 105 125", 
                      "M 92 125 Q 100 145 108 125 Z", 
                      "M 92 125 Q 100 145 108 125 Z", 
                      "M 95 125 Q 100 130 105 125",
                      "M 95 125 Q 100 130 105 125"
                    ],
                    fill: [
                      "transparent", 
                      "transparent", 
                      "#EF4444", 
                      "#EF4444", 
                      "transparent",
                      "transparent"
                    ]
                  }
            }
            transition={
              isTyping
                ? { duration: 0.2 }
                : { duration: 5, repeat: Infinity, times: [0, 0.6, 0.65, 0.85, 0.9, 1] }
            }
            stroke="#db2777"
            strokeWidth="2"
            strokeLinecap="round"
          />
          
          {/* Arms */}
          <motion.g animate={isTyping ? { rotate: [-40, 50, -40] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.25 }} style={{ originX: '45px', originY: '135px' }}>
            <path d="M 45 135 Q 15 145 30 165" fill="none" stroke="#db2777" strokeWidth="8" strokeLinecap="round"/>
          </motion.g>
          <motion.g animate={isTyping ? { rotate: [40, -50, 40] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.25 }} style={{ originX: '155px', originY: '135px' }}>
            <path d="M 155 135 Q 185 145 170 165" fill="none" stroke="#db2777" strokeWidth="8" strokeLinecap="round"/>
          </motion.g>
        </motion.g>
      </svg>
    </div>
  );
};

const Squirtle = ({ isTyping, mousePos }: { isTyping: boolean, mousePos: { x: number, y: number } }) => {
  const winWidth = typeof window !== 'undefined' ? window.innerWidth : 1000;
  const winHeight = typeof window !== 'undefined' ? window.innerHeight : 1000;
  
  const isMobile = winWidth < 768;
  const charX = isMobile ? winWidth / 2 : winWidth * 0.25; 
  const charY = isMobile ? 100 : winHeight / 2 - 100;

  const dx = mousePos.x - charX;
  const dy = mousePos.y - charY;
  const angle = Math.atan2(dy, dx);
  
  const maxDist = 4;
  const dist = Math.min(Math.sqrt(dx * dx + dy * dy) / 40, maxDist);
  
  const eyeX = Math.cos(angle) * dist;
  const eyeY = Math.sin(angle) * dist;

  return (
    <div className="relative">
      <AnimatePresence>
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, scale: 0, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0 }}
            className="absolute -top-4 right-4 z-20 text-blue-500 font-black text-2xl drop-shadow-md"
          >
            💧
          </motion.div>
        )}
      </AnimatePresence>
      <svg viewBox="0 0 200 200" className="w-48 h-48 drop-shadow-xl overflow-visible">
        {/* Tail */}
        <motion.g animate={isTyping ? { rotate: [0, 15, -5, 0] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.6 }} style={{ originX: '130px', originY: '150px' }}>
          <path d="M 120 150 C 180 160 190 100 150 90 C 130 85 140 110 155 110 C 170 110 160 130 140 130 Z" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3" strokeLinejoin="round"/>
        </motion.g>

        {/* Left Leg */}
        <motion.g animate={isTyping ? { y: [-4, 0, -4] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.35 }} style={{ originX: '75px', originY: '170px' }}>
          <ellipse cx="75" cy="170" rx="15" ry="10" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3"/>
        </motion.g>

        {/* Right Leg */}
        <motion.g animate={isTyping ? { y: [0, -4, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.35 }} style={{ originX: '125px', originY: '170px' }}>
          <ellipse cx="125" cy="170" rx="15" ry="10" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3"/>
        </motion.g>

        {/* Body Group */}
        <motion.g animate={isTyping ? { y: [0, -6, 0] } : { y: 0 }} transition={{ repeat: Infinity, duration: 0.35 }}>
          {/* Back Shell */}
          <path d="M 55 110 C 30 130 40 165 60 165 L 140 165 C 160 165 170 130 145 110 C 160 90 140 70 100 70 C 60 70 40 90 55 110 Z" fill="#B45309" stroke="#78350F" strokeWidth="3"/>
          
          {/* Shell rim */}
          <path d="M 55 110 C 30 130 40 165 60 165 L 140 165 C 160 165 170 130 145 110" fill="none" stroke="#F3F4F6" strokeWidth="10" strokeLinecap="round"/>
          <path d="M 55 110 C 30 130 40 165 60 165 L 140 165 C 160 165 170 130 145 110" fill="none" stroke="#D1D5DB" strokeWidth="10" strokeLinecap="round" style={{ mixBlendMode: 'multiply', opacity: 0.3 }} transform="translate(0, 2)"/>

          {/* Main Body */}
          <ellipse cx="100" cy="135" rx="35" ry="40" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3"/>

          {/* Front Shell (Belly) */}
          <ellipse cx="100" cy="138" rx="28" ry="32" fill="#FEF08A" stroke="#CA8A04" strokeWidth="3"/>
          {/* Shell lines */}
          <path d="M 80 120 L 120 120 M 75 140 L 125 140 M 80 160 L 120 160 M 100 106 L 100 170" stroke="#CA8A04" strokeWidth="2" opacity="0.5"/>

          {/* Head */}
          <circle cx="100" cy="75" r="35" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3"/>

          {/* Eyes Sockets */}
          <g>
            <ellipse cx="82" cy="70" rx="6" ry="10" fill="#FFF" stroke="#0284C7" strokeWidth="2"/>
            <ellipse cx="118" cy="70" rx="6" ry="10" fill="#FFF" stroke="#0284C7" strokeWidth="2"/>
          </g>

          {/* Pupils */}
          <motion.g animate={{ x: eyeX, y: eyeY, scale: isTyping ? 1.1 : 1 }} style={{ originX: '100px', originY: '70px' }}>
            <circle cx="82" cy="70" r="3" fill="#450A0A"/>
            <circle cx="118" cy="70" r="3" fill="#450A0A"/>
          </motion.g>

          {/* Mouth */}
          <motion.path
            d={isTyping ? "M 90 90 Q 100 105 110 90 Z" : "M 90 90 Q 100 95 110 90"}
            fill={isTyping ? "#EF4444" : "none"}
            stroke="#0284C7"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Left Arm */}
          <motion.g animate={isTyping ? { rotate: [-20, 30, -20] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.25 }} style={{ originX: '65px', originY: '125px' }}>
            <path d="M 65 125 Q 35 135 45 155 Q 55 145 65 135 Z" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3" strokeLinejoin="round"/>
          </motion.g>
          {/* Right Arm */}
          <motion.g animate={isTyping ? { rotate: [20, -30, 20] } : { rotate: 0 }} transition={{ repeat: Infinity, duration: 0.25 }} style={{ originX: '135px', originY: '125px' }}>
            <path d="M 135 125 Q 165 135 155 155 Q 145 145 135 135 Z" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3" strokeLinejoin="round"/>
          </motion.g>
        </motion.g>
      </svg>
    </div>
  );
};

export default function App() {
  const [isTyping, setIsTyping] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setMousePos({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleInput = () => {
    setIsTyping(true);
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
    }, 600);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 font-sans">
      <div className="max-w-5xl w-full bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        
        {/* Left Panel - Characters */}
        <div className="w-full md:w-1/2 bg-gradient-to-br from-emerald-300 via-teal-400 to-cyan-500 relative overflow-hidden flex items-center justify-center min-h-[300px] md:min-h-full p-8">
          {/* Decorative background elements */}
          <div className="absolute top-10 left-10 w-32 h-32 bg-white/20 rounded-full blur-2xl"></div>
          <div className="absolute bottom-10 right-10 w-48 h-48 bg-emerald-600/20 rounded-full blur-3xl"></div>
          
          <div className="relative w-full max-w-sm aspect-square flex items-center justify-center">
            {/* Squirtle (top center, behind others) */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 z-0">
              <Squirtle isTyping={isTyping} mousePos={mousePos} />
            </div>

            {/* Jigglypuff (slightly behind and to the left) */}
            <div className="absolute bottom-12 left-0 z-10">
              <Jigglypuff isTyping={isTyping} mousePos={mousePos} />
            </div>
            
            {/* Pikachu (front and right) */}
            <div className="absolute bottom-4 right-0 z-20">
              <Pikachu isTyping={isTyping} mousePos={mousePos} />
            </div>
          </div>
        </div>

        {/* Right Panel - Login Form */}
        <div className="w-full md:w-1/2 p-8 md:p-16 flex flex-col justify-center bg-white">
          <div className="max-w-md w-full mx-auto">
            <div className="mb-10 text-center md:text-left">
              <h1 className="text-4xl font-black text-slate-800 mb-3 tracking-tight">¡Hola de nuevo!</h1>
              <p className="text-slate-500 text-lg">Inicia sesión para continuar tu aventura.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Correo Electrónico</label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-teal-500 transition-colors">
                    <Mail size={20} />
                  </div>
                  <input
                    type="email"
                    placeholder="entrenador@pokemon.com"
                    onChange={handleInput}
                    className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl text-slate-800 placeholder-slate-400 focus:outline-none focus:border-teal-500 focus:bg-white transition-all duration-300"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Contraseña</label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-teal-500 transition-colors">
                    <Lock size={20} />
                  </div>
                  <input
                    type="password"
                    placeholder="••••••••"
                    onChange={handleInput}
                    className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl text-slate-800 placeholder-slate-400 focus:outline-none focus:border-teal-500 focus:bg-white transition-all duration-300"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input type="checkbox" className="w-5 h-5 rounded border-slate-300 text-teal-500 focus:ring-teal-500" />
                  <span className="text-sm font-medium text-slate-600">Recordarme</span>
                </label>
                <a href="#" className="text-sm font-bold text-teal-600 hover:text-teal-500 transition-colors">
                  ¿Olvidaste tu contraseña?
                </a>
              </div>

              <button
                type="submit"
                className="w-full mt-8 bg-slate-800 hover:bg-slate-900 text-white font-bold py-4 px-8 rounded-2xl flex items-center justify-center space-x-2 transform hover:-translate-y-1 transition-all duration-300 shadow-lg hover:shadow-xl active:scale-95"
              >
                <span>Entrar a la cuenta</span>
                <ArrowRight size={20} />
              </button>
            </form>
            
            <p className="mt-8 text-center text-sm font-medium text-slate-500">
              ¿No tienes una cuenta? <a href="#" className="text-teal-600 font-bold hover:underline">Regístrate aquí</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
